/*
 * Data Structure Rules:
 * - Products: Single source of truth for product details and current prices. Never duplicated.
 * - Carts: Represents user shopping sessions. Each cart has:
 *   - 'status' set to "active" (in-progress) or "converted" (finalized and turned into an order).
 *   - When a cart's status changes from "active" to "converted", it becomes an order.
 * - Orders: Tracks finalized purchases by referencing a cart via 'cart_id'.
 *   - Does not duplicate 'items'; instead, uses 'cart_id' to link to the cart's items.
 * - Users: Unique user records linked to carts and orders via 'user_id'. 
 */

/*
 * Relationships Between Entities:
 * - Products ↔ Carts (Many-to-Many, Bidirectional): 
 *   - A single product can appear in multiple carts (e.g., "MacBook Pro" in cart_1 and potentially others).
 *   - A single cart can contain multiple products (e.g., cart_1 has "MacBook Pro" and "Atomic Habits").
 *   - Linked via 'prod_id' in carts' 'items' array referencing 'prod_id' in products.
 * - Users → Carts (One-to-One, Unidirectional): 
 *   - Each user has exactly one cart at a time (e.g., user_1 has cart_1).
 *   - A cart belongs to only one user, referenced by 'user_id' in carts pointing to 'user_id' in users.
 *   - Direction is from users to carts; carts don’t need to reference back beyond 'user_id'.
 * - Carts → Orders (One-to-One, Unidirectional): 
 *   - Each cart, once converted, becomes exactly one order (e.g., cart_1 becomes order_1).
 *   - An order references only one cart via 'cart_id', and the relationship flows from cart to order.
 * - Users → Orders (One-to-Many, Unidirectional): 
 *   - A user can have multiple orders (e.g., user_1 could have more than order_1 in the future).
 *   - An order belongs to one user, linked by 'user_id' in orders pointing to 'user_id' in users.
 */

let products = [
    { prod_id: "1", name: "MacBook Pro", description: "Powerful laptop with M3 chip.", price: 2499.99, category: "electronics", image: "https://example.com/images/macbook.jpg" },
    { prod_id: "2", name: "Sony Headphones", description: "Noise-canceling with hi-res audio.", price: 399.99, category: "electronics", image: "https://example.com/images/sony_headphones.jpg" },
    { prod_id: "3", name: "iPad Air", description: "Lightweight tablet with M2 chip.", price: 699.99, category: "electronics", image: "https://example.com/images/ipad_air.jpg" },
    { prod_id: "4", name: "Gatsby", description: "Classic novel by F. Scott Fitzgerald.", price: 10.99, category: "books", image: "https://example.com/images/gatsby.jpg" },
    { prod_id: "5", name: "Atomic Habits", description: "Bestseller on habit-building.", price: 16.99, category: "books", image: "https://example.com/images/atomic_habits.jpg" },
    { prod_id: "6", name: "Sapiens", description: "A brief history of humankind.", price: 18.99, category: "books", image: "https://example.com/images/sapiens.jpg" },
    { prod_id: "7", name: "Fitbit", description: "Fitness tracker with heart rate monitor.", price: 129.99, category: "health", image: "https://example.com/images/fitbit.jpg" },
    { prod_id: "8", name: "Yoga Mat", description: "Non-slip mat for home workouts.", price: 39.99, category: "health", image: "https://example.com/images/yoga_mat.jpg" },
    { prod_id: "9", name: "Massage Gun", description: "Deep tissue muscle massager.", price: 149.99, category: "health", image: "https://example.com/images/massage_gun.jpg" },
    { prod_id: "10", name: "LEGO Falcon", description: "Millennium Falcon LEGO set.", price: 159.99, category: "toys", image: "https://example.com/images/lego_falcon.jpg" },
    { prod_id: "11", name: "RC Car", description: "High-speed remote control car.", price: 89.99, category: "toys", image: "https://example.com/images/rc_car.jpg" },
    { prod_id: "12", name: "Board Game", description: "Fun strategy game for all ages.", price: 49.99, category: "toys", image: "https://example.com/images/board_game.jpg" }
];

let carts = [
    { cart_id: "cart_1", user_id: "user_1", items: [{ prod_id: "1", quantity: 1, price_at_time: 2499.99 }, { prod_id: "5", quantity: 2, price_at_time: 16.99 }], total_amount: 2533.97, status: "converted" },
    { cart_id: "cart_2", user_id: "user_3", items: [{ prod_id: "10", quantity: 1, price_at_time: 159.99 }, { prod_id: "7", quantity: 1, price_at_time: 129.99 }, { prod_id: "6", quantity: 1, price_at_time: 18.99 }], total_amount: 308.97, status: "converted" },
    { cart_id: "cart_3", user_id: "user_2", items: [{ prod_id: "2", quantity: 1, price_at_time: 399.99 }, { prod_id: "8", quantity: 2, price_at_time: 39.99 }], total_amount: 479.97, status: "converted" },
    { cart_id: "cart_4", user_id: "user_4", items: [{ prod_id: "3", quantity: 1, price_at_time: 699.99 }, { prod_id: "4", quantity: 3, price_at_time: 10.99 }], total_amount: 732.96, status: "converted" },
    { cart_id: "cart_5", user_id: "user_5", items: [{ prod_id: "9", quantity: 1, price_at_time: 149.99 }, { prod_id: "11", quantity: 2, price_at_time: 89.99 }, { prod_id: "12", quantity: 1, price_at_time: 49.99 }], total_amount: 379.96, status: "converted" }
];

let users = [
    { user_id: "user_1", name: "John Doe", phone: "123-456-7890", dob: "1990-03-15", address: "123 Main St, New York, NY", image: "https://example.com/images/john_doe.jpg" },
    { user_id: "user_2", name: "Alice Johnson", phone: "234-567-8901", dob: "1985-06-22", address: "456 Oak St, Los Angeles, CA", image: "https://example.com/images/alice_johnson.jpg" },
    { user_id: "user_3", name: "Michael Smith", phone: "345-678-9012", dob: "1992-09-10", address: "789 Pine St, Chicago, IL", image: "https://example.com/images/michael_smith.jpg" },
    { user_id: "user_4", name: "Emily Davis", phone: "456-789-0123", dob: "1988-12-05", address: "159 Cedar St, Miami, FL", image: "https://example.com/images/emily_davis.jpg" },
    { user_id: "user_5", name: "David Wilson", phone: "567-890-1234", dob: "1995-07-30", address: "753 Birch St, Seattle, WA", image: "https://example.com/images/david_wilson.jpg" }
];

let orders = [
    { order_id: "order_1", cart_id: "cart_1", user_id: "user_1", total_amount: 2533.97, order_date: "2023-10-01", status: "delivered" },
    { order_id: "order_2", cart_id: "cart_2", user_id: "user_3", total_amount: 308.97, order_date: "2023-10-02", status: "shipped" },
    { order_id: "order_3", cart_id: "cart_3", user_id: "user_2", total_amount: 479.97, order_date: "2025-03-18", status: "shipped" },
    { order_id: "order_4", cart_id: "cart_4", user_id: "user_4", total_amount: 732.96, order_date: "2025-03-19", status: "pending" },
    { order_id: "order_5", cart_id: "cart_5", user_id: "user_5", total_amount: 379.96, order_date: "2025-03-20", status: "pending" }
];

/* 
Product -> Carts (Many-to-Many, Bidirectional): A product can be in multiple carts, and a cart can have many products. This is a many-to-many relationship.
Users -> Cart (One-to-One, Unidirectional): Each user has only one cart, and a cart belongs to one user. This is a one-to-one relationship.
*/
export {carts, products, users, orders};