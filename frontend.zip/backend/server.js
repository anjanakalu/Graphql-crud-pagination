import express from 'express';
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4'; // import the express middleware
import cors from 'cors'
import mergedTypeDefs from './typeDefs/index.js';
import mergedResolvers from './resolvers/index.js';
import dotenv from 'dotenv';
import { connectDB } from './db_connect/connectDB.js';
// Initialize an Express application
const app = express();

// Load environment variables from .env file
dotenv.config();

// Connect to MongoDB
connectDB();

// Create an Apollo Server instance
const server = new ApolloServer({
    typeDefs : mergedTypeDefs,
    resolvers: mergedResolvers,
});

async function startServer() {
    // Start Apollo Server
    await server.start();

    // Apply Apollo middleware to Express
    app.use(
        '/',
        cors({
            origin: "http://localhost:3000",
            credentials: true
        }),
        express.json(),
        expressMiddleware(server));

    // Start the Express server
    const PORT = process.env.PORT || 4000;
    app.listen(PORT, () => {
        console.log(`Server is running at http://localhost:${PORT}`);
    });
}

startServer();
