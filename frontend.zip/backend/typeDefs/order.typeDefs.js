/*
 * Schema Rules:
 * 1. Separate entity (Order) into order.typeDefs.js with type, Query, Mutation, input defs.
 * 2. Define Order type with all fields (e.g., order_id, cart_id) using proper scalars and nullability.
 * 3. Query: Get all orders (orders: [Order!]!) and by ID (order(id: ID!): Order).
 * 4. Mutation: Create, update, delete with inputs; return Order (nullable).
 * 5. Input: CreateOrderInput (required fields), UpdateOrderInput (optional fields), matching Order type.
 * 6. Stored in schema/; merged in index.js with relationships.
 */

const orderTypeDefs = `#graphql
type Order {
    order_id: ID!
    cart_id: ID!
    user_id: ID!
    total_amount: Float!
    order_date: String!
    status: String!
  }

  type Query {
    orders: [Order!]!
    order(order_id: ID!): Order
  }

  type Mutation {
    createOrder(order: CreateOrderInput!): Order
    updateOrder(order_id: ID!, order: UpdateOrderInput!): Order
    deleteOrder(order_id: ID!): Order
  }

  input CreateOrderInput {
    cart_id: ID!
    user_id: ID!
    total_amount: Float!
    order_date: String!
    status: String!
  }

  input UpdateOrderInput {
    cart_id: ID
    user_id: ID
    total_amount: Float
    order_date: String
    status: String
  }
`
export default orderTypeDefs;