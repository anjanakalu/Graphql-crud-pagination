/*
 * Schema Rules:
 * 1. Separate entity (Cart) into cart.typeDefs.js with type, Query, Mutation, input defs.
 * 2. Define Cart/CartItem types with all fields (e.g., id, items) using proper scalars and nullability.
 * 3. Query: Get all carts (carts: [Cart!]!) and by ID (cart(id: ID!): Cart).
 * 4. Mutation: Create, update, delete with inputs; return Cart (nullable).
 * 5. Input: CreateCartInput (required fields), UpdateCartInput (optional fields), matching Cart type.
 * 6. Stored in schema/; merged in index.js with relationships.
 */

const cartTypeDefs = `#graphql
type CartItem {
    prod_id: ID!
    quantity: Int!
    price_at_time: Float!
  }

  type Cart {
    id: ID!
    user_id: ID!
    items: [CartItem!]!
    total_amount: Float!
    status: String!
  }

  type Query {
    carts: [Cart!]!
    cart(id: ID!): Cart
  }

  type Mutation {
    createCart(cart: CreateCartInput!): Cart
    updateCart(id: ID!, cart: UpdateCartInput!): Cart
    deleteCart(id: ID!): Cart
  }

  input CreateCartInput {
    user_id: ID!
    items: [CartItemInput!]!
    total_amount: Float!
    status: String!
  }

  input UpdateCartInput {
    user_id: ID
    items: [CartItemInput!]
    total_amount: Float
    status: String
  }

  input CartItemInput {
    prod_id: ID!
    quantity: Int!
    price_at_time: Float!
  }
`

export default cartTypeDefs;