/*
 * Schema Rules:
 * 1. Separate each entity (e.g., Product) into its own file as entityName.typeDefs.js, including type, Query, Mutation, and input defs.
 * 2. Define entity type with all fields, using proper scalar types (e.g., ID, String, Float) and nullability (!).
 * 3. Query: Include get all (e.g., products: [Product!]!) and get by ID (e.g., product(id: ID!): Product).
 * 4. Mutation: Define create, update, delete with inputs; return entity (nullable).
 * 5. Input: Create<Entity>Input (required fields with !), Update<Entity>Input (optional fields), matching type fields.
 * 6. Store in schema/ dir; merge in index.js with mergeTypeDefs, adding relationships.
 */

/*
 * Pagination Rules (Cursor-Based):
 * - Implements Relay-style cursor pagination using Connection/Edge/PageInfo pattern
 * - Core Components:
 *   • Edge: Pairs a node with its cursor (ProductEdge = cursor + node)
 *   • Node: The individual data object (Product entity)
 *   • Cursor: Opaque, unique string identifier marking an item's position in the dataset
 *   • PageInfo: Metadata indicating pagination state and navigation options
 *   • TotalCount: Total number of items in the dataset
 * - Pagination Mechanics:
 *   • Forward: 'first' (count) and 'after' (cursor) fetch items after a given point
 *   • Backward: 'last' (count) and 'before' (cursor) fetch items before a given point
 *   • Cursor Purpose: Encodes position (e.g., last node's ID or timestamp) for stable pagination
 * - Return Structure: ProductConnection return Pagination results
 *   • ProductConnection: Encapsulates paginated results with:
 *     - edges: Non-nullable array of ProductEdge (cursor + node pairs)
 *     - pageInfo: Non-nullable metadata for navigation (endCursor, hasNext/PreviousPage)
 *     - totalCount: Non-nullable count of all items
 * - Optional Filters: searchText, category (applied before pagination)
 * - Advantages: Stable against data changes, efficient for large datasets
 */

const productTypeDefs = `#graphql
  # Product entity definition
  type Product {
    prod_id: ID!          # Unique identifier, required
    name: String!         # Product name, required
    description: String!  # Product description, required
    price: Float!         # Price in decimal format, required
    category: String!     # Category classification, required
    image: String!        # Image URL or path, required
  }

  # Single paginated item with its position marker
  type ProductEdge {
    cursor: String!       # Opaque string encoding this product's position
    node: Product!        # The Product object, non-nullable
  }

  # Pagination navigation metadata
  type PageInfo {
    startCursor: String
    endCursor: String     # Cursor of the last item in this page, nullable if none
    hasNextPage: Boolean! # True if more items follow this page
    hasPreviousPage: Boolean! # True if items precede this page
    currentPage: Int!
    totalPages: Int!
  }

  # Paginated result set
  type ProductConnection {
    edges: [ProductEdge!]!    # Array of product edges, always present
    pageInfo: PageInfo!       # Navigation info, always present
    totalCount: Int!          # Total products in dataset, always present
  }

  # Core queries
  type Query {
    product(prod_id: ID!): Product    # Single product by ID, nullable on not found
    
    products(                         # Cursor-paginated product list
      first: Int                      # Items to fetch forward (optional)
      after: String                   # Start after this cursor (optional)
      last: Int                       # Items to fetch backward (optional)
      before: String                  # Start before this cursor (optional)
      searchText: String              # Filter by text (optional)
      category: String                # Filter by category (optional)
      sortBy: String
      sortOrder: String
      pageSize: Int
    ): ProductConnection!            # Returns paginated results, never null
  }

  # Extended queries
  extend type Query {
    productsByCategoryAndSearch(     # Non-paginated filtered list
      searchText: String             # Optional text filter
      category: String               # Optional category filter
    ): [Product]!                   # Return Non-nullable Product array
    
    categories: [String!]!          # All unique categories
    productsInCategory(             # Non-paginated category list
      category: String              # Optional category filter
    ): [Product]!                   # Return Non-nullable Product array
  }

  # Product mutations
  type Mutation {
    createProduct(                   # Add new product
      product: CreateProductInput!  # Required creation data
    ): Product!                      # Return Non-nullable Product
    
    updateProduct(                  # Modify existing product
      prod_id: ID!                 # Target ID, required
      product: UpdateProductInput! # Update data, required
    ): Product!                       # Return Non-nullable Product
    
    deleteProduct(                 # Remove product
      prod_id: ID!                # Target ID, required
    ): Product!                     # Return Non-nullable Product
  }

  # Required fields for product creation
  input CreateProductInput {
    name: String!         # Mandatory name
    description: String!  # Mandatory description
    price: Float!         # Mandatory price
    category: String!     # Mandatory category
    image: String!        # Mandatory image
  }

  # Optional fields for product updates
  input UpdateProductInput {
    name: String         # Optional name update
    description: String  # Optional description update
    price: Float         # Optional price update
    category: String     # Optional category update
    image: String        # Optional image update
  }
`;

export default productTypeDefs;



/* 
const productTypeDefs = `#graphql
type Product {
    prod_id: ID!
    name: String!
    description: String!
    price: Float!
    category: String!
    image: String!
  }

  type ProductEdge {
  cursor: String!
  node: Product!
}
type PageInfo {
  endCursor: String
  hasNextPage: Boolean!
  hasPreviousPage: Boolean!
}

type ProductConnection {
  edges: [ProductEdge!]!
  pageInfo: PageInfo!
  totalCount: Int!
}

type Query {
    # products: [Product!]!
    product(prod_id: ID!): Product
    products(
      first:Int
      after: String
      last: Int
      before: String
      searchText: String
      category: String
    ): ProductConnection!
  }

extend type Query {  # Extend the existing Query type
  productsByCategoryAndSearch(searchText: String, category:String): [Product]!
  categories:[String!]!
  productsInCategory(category:String):[Product]!
  }

  type Mutation {
    createProduct(product: CreateProductInput!): Product
    updateProduct(prod_id: ID!, product: UpdateProductInput!): Product
    deleteProduct(prod_id: ID!): Product
  }

  input CreateProductInput {
    name: String!
    description: String!
    price: Float!
    category: String!
    image: String!
  }

  input UpdateProductInput {
    name: String
    description: String
    price: Float
    category: String
    image: String
  }
`
export default productTypeDefs; */