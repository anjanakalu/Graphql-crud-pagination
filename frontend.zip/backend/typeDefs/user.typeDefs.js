/*
 * Schema Rules:
 * 1. Separate entity (User) into user.typeDefs.js with type, Query, Mutation, input defs.
 * 2. Define User type with all fields (e.g., user_id, name) using proper scalars and nullability.
 * 3. Query: Get all users (users: [User!]!) and by ID (user(id: ID!): User).
 * 4. Mutation: Create, update, delete with inputs; return User (nullable).
 * 5. Input: CreateUserInput (required fields), UpdateUserInput (optional fields), matching User type.
 * 6. Stored in schema/; merged in index.js with relationships.
 */

const userTypeDefs = `#graphql
type User {
    user_id: ID!
    name: String!
    phone: String!
    dob: String!
    address: String!
    image: String!
  }

  type Query {
    users: [User!]!
    user(user_id: ID!): User
  }

  type Mutation {
    createUser(user: CreateUserInput!): User
    updateUser(user_id: ID!, user: UpdateUserInput!): User
    deleteUser(user_id: ID!): User
  }

  input CreateUserInput {
    name: String!
    phone: String!
    dob: String!
    address: String!
    image: String!
  }

  input UpdateUserInput {
    name: String
    phone: String
    dob: String
    address: String
    image: String
  }
`
export default userTypeDefs;