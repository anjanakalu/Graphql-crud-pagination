import { mergeTypeDefs } from "@graphql-tools/merge";
import orderTypeDefs from './order.typeDefs.js';
import productTypeDefs from './product.typeDefs.js';
import cartTypeDefs from './cart.typeDefs.js'; 
import userTypeDefs from './user.typeDefs.js';

/*
 * Schema Rules (Integration):
 * 1. All entity schemas (order, product, cart, user) are imported from separate *.typeDefs.js files.
 * 2. Relationships (e.g., Cart.user, User.carts) defined here, not in entity files, for linking.
 * 3. Merge all type definitions into a single schema using mergeTypeDefs.
 */

// Define relationships between entities separately in this file for linking, rather than within individual entity schema files
const linkSchema = `#graphql
  type Cart {
    user: User
  }

  type Order {
    cart: Cart
    user: User
  }

  type User {
    carts: [Cart!]
    orders: [Order!]
  }

  type CartItem {
    product: Product
  }
`;

// Merge all type definitions into a single schema
const mergedTypeDefs = mergeTypeDefs([
  orderTypeDefs,
  productTypeDefs,
  cartTypeDefs, 
  userTypeDefs,
  linkSchema
]);

export default mergedTypeDefs;