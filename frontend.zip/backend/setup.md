npm install express @apollo/server graphql cors mongoose dotenv 
npm install --save-dev nodemon