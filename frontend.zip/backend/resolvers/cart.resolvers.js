import { carts } from "../_dummy_data/dummyData.js"
import Cart from "../models/carts.model.js"
const cartResolvers = {
    Query: {
        // Fetch all carts
        carts: async () => {
            try {
                return await Cart.find();
            } catch (error) {
                throw new Error('Error fetching carts');
            }
        }
    },
    Mutation: {
        createCart: async (_, { cart }) => {
            try {
             let totalAmount = 0;
             for(let item of cart.items) {
                
             }   
            } catch (error) {
                
            }
        }
    }
}

export default cartResolvers;