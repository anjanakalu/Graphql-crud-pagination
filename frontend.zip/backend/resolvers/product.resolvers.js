// import { products } from "../_dummy_data/dummyData.js";
import mongoose from "mongoose";
import Product from "../models/products.model.js";
import { base64encode, base64decode } from 'nodejs-base64';


const productResolvers = {
    Query: {
        /* products: async (_, { first, after, last, before, searchText, category, sortBy, sortOrder, pageSize=10 }) => {
            // try {
            //     const products = await Product.find();
            //     return products;
            // } catch (error) {
            //     throw new Error(`Failed to fetch users: ${error.message}`);
            // }
            try {
                // Fetch all products
                let products = await Product.find();

                if (searchText) {
                    products = products.filter(p => p.name.toLowerCase().includes(searchText.toLowerCase()));
                }

                if (category) {
                    products = products.filter(p => p.category === category);
                }
                const fieldMap = { "Product Name": "Name", "prod_id": "prod_id" };
                const sortField = fieldMap[sortBy] || sortBy;

                const copyOfProducts = products.map(product => product);

                if (sortField) {
                    copyOfProducts.sort((a, b) => {
                        const aValue = a[sortField];
                        const bValue = b[sortField];

                        // If both values are numbers
                        if (typeof aValue === "number" && typeof bValue === "number") {
                            return sortOrder === "ASC" ? aValue - bValue : bValue - aValue;
                        }

                        // If both values are strings
                        if (typeof aValue === "string" && typeof bValue === "string") {
                            return sortOrder === "ASC" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
                        }
                    });
                }



                if (first && last) throw new Error('Cannot use both first and last');

                if ((first || last) && (last || before)) {
                    throw new Error('Mixing forward and backward pagination is invalid');
                }

                // Totalcount and totalpages
                const totalCount = products.length;
                const totalPages = Math.ceil(totalCount / pageSize);

                // Decode Cursors:

                const decodeCursor = (cursor) => cursor ? parseInt(base64decode(cursor)) : null;

                const afterId = decodeCursor(after);
                const beforeId = decodeCursor(before);
                // Determine slice
                let startIndex = afterId ? products.findIndex(p => p.prod_id === afterId) + 1 : 0;
                let endIndex = beforeId ? products.findIndex(p => prod_id === beforeId) : 0;

                if (startIndex === -1 || endIndex === -1) {
                    throw new Error("Invalid Cursor Provided");
                }

                if (first) {
                    endIndex = Math.min(startIndex + first, totalCount);
                } else if (last) {
                    startIndex = Math.max(endIndex - last, 0)
                }

                const paginatedProducts = products.slice(startIndex, endIndex);

                const currentPage = Math.ceil(endIndex/pageSize);
                // Build Edges
                const edges = paginatedProducts.map(product => ({
                    cursor: base64encode(product.prod_id.toString()),
                    node: product
                }));

                // Page Info
                const pageInfo = {
                    startCursor: edges.length > 0 ? edges[0].cursor : null,
                    endCursor: edges.length > 0 ? edges[edges.length - 1].cursor : null,
                    hasNextPage: endIndex < totalCount,
                    hasPreviousPage: startIndex > 0,
                    currentPage:1,
                    totalPages: totalPages
                }
                return {
                    edges,
                    pageInfo,
                    totalCount
                }
            } catch (error) {
                throw new Error(`Pagination error: ${error.message}`);
            }
        } */
        /* products: async (_, { first, after, last, before, searchText, category, sortBy, sortOrder, pageSize = 10 }) => {
            // any change on this params, update it on query.products typeDef:
            try {
                // Fetch all products
                let products = await Product.find();
 
                // Apply filters
                if (searchText) {
                    products = products.filter(p => p.name.toLowerCase().includes(searchText.toLowerCase()));
                }
                if (category) {
                    products = products.filter(p => p.category === category);
                }
 
                // Apply sorting
                const fieldMap = { "Product Name": "name", "prod_id": "prod_id" };
                const sortField = fieldMap[sortBy] || sortBy;
                const copyOfProducts = products.map(product => product);
 
                if (sortField) {
                    copyOfProducts.sort((a, b) => {
                        const aValue = a[sortField];
                        const bValue = b[sortField];
 
                        if (typeof aValue === "number" && typeof bValue === "number") {
                            return sortOrder === "ASC" ? aValue - bValue : bValue - aValue;
                        }
                        if (typeof aValue === "string" && typeof bValue === "string") {
                            return sortOrder === "ASC" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
                        }
                        return 0;
                    });
                }
 
                // Validate pagination parameters
                if (first && last) throw new Error('Cannot use both first and last');
                if ((first && before) || (last && after)) {
                    throw new Error('Mixing forward and backward pagination is invalid');
                }
 
                // Calculate total count and pages
                const totalCount = copyOfProducts.length;
                const totalPages = Math.ceil(totalCount / pageSize);
 
                // Decode cursors
                const decodeCursor = (cursor) => cursor ? parseInt(Buffer.from(cursor, 'base64').toString('ascii')) : null;
                const afterId = decodeCursor(after);
                const beforeId = decodeCursor(before);
 
                // Determine slice indices
                let startIndex = afterId ? copyOfProducts.findIndex(p => p.prod_id === afterId) + 1 : 0;
                let endIndex = beforeId ? copyOfProducts.findIndex(p => p.prod_id === beforeId) : totalCount;
 
                if (startIndex === -1 || endIndex === -1) {
                    throw new Error("Invalid cursor provided");
                }
 
                // Adjust indices based on pagination type
                if (first) {
                    endIndex = Math.min(startIndex + first, totalCount);
                } else if (last) {
                    startIndex = Math.max(endIndex - last, 0);
                }
 
                // Get paginated products
                const paginatedProducts = copyOfProducts.slice(startIndex, endIndex);
 
                // Calculate current page
                let currentPage;
                if (first || after) {
                    currentPage = Math.floor(startIndex / pageSize) + 1;
                } else if (last || before) {
                    currentPage = Math.ceil(endIndex / pageSize);
                } else {
                    currentPage = 1; // Default to first page
                }
 
                // Build edges
                const edges = paginatedProducts.map(product => ({
                    cursor: Buffer.from(product.prod_id.toString()).toString('base64'),
                    node: product
                }));
 
                // Return pagination result
                return {
                    edges,
                    pageInfo: {
                        startCursor: edges[0]?.cursor || null,
                        endCursor: edges[edges.length - 1]?.cursor || null,
                        hasNextPage: endIndex < totalCount,
                        hasPreviousPage: startIndex > 0,
                        currentPage,
                        totalPages
                    },
                    totalCount
                };
            } catch (error) {
                throw new Error(`Pagination error: ${error.message}`);
            }
        } */
        /*   products: async (_, { first, after, last, before, searchText, category, sortBy, sortOrder, pageSize = 5 }) => {
              try {
                  // Fetch all products
                  let products = await Product.find();
          
                  // Apply filters
                  if (searchText) {
                      products = products.filter(p => p.name.toLowerCase().includes(searchText.toLowerCase()));
                  }
                  if (category) {
                      products = products.filter(p => p.category === category);
                  }
          
                  // Apply sorting
                  const fieldMap = { "Product Name": "name", "prod_id": "prod_id" };
                  const sortField = fieldMap[sortBy] || sortBy;
                  const sortedProducts = [...products]; // Create a copy for sorting
          
                  if (sortField) {
                      sortedProducts.sort((a, b) => {
                          const aValue = a[sortField];
                          const bValue = b[sortField];
          
                          if (typeof aValue === "number" && typeof bValue === "number") {
                              return sortOrder === "ASC" ? aValue - bValue : bValue - aValue;
                          }
                          if (typeof aValue === "string" && typeof bValue === "string") {
                              return sortOrder === "ASC" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
                          }
                          return 0;
                      });
                  }
          
                  // Validate pagination parameters
                  if (first && last) throw new Error('Cannot use both first and last');
                  if ((first && before) || (last && after)) {
                      throw new Error('Mixing forward and backward pagination is invalid');
                  }
          
                  const totalCount = sortedProducts.length;
                  const totalPages = Math.ceil(totalCount / pageSize);
          
                  // Cursor handling - treat as string IDs, not numbers
                  const decodeCursor = (cursor) => cursor ? Buffer.from(cursor, 'base64').toString('ascii') : null;
                  const afterId = decodeCursor(after);
                  const beforeId = decodeCursor(before);
          
                  // Find positions
                  let startIndex = afterId 
                      ? sortedProducts.findIndex(p => p.prod_id === afterId) + 1 
                      : 0;
                  let endIndex = beforeId 
                      ? sortedProducts.findIndex(p => p.prod_id === beforeId) 
                      : sortedProducts.length;
          
                  if (startIndex === -1 || endIndex === -1) {
                      throw new Error("Invalid cursor provided");
                  }
          
                  // Apply pagination limits
                  if (first) {
                      endIndex = Math.min(startIndex + first, sortedProducts.length);
                  } else if (last) {
                      startIndex = Math.max(endIndex - last, 0);
                  }
          
                  // Calculate current page based on actual position
                  const currentPage = Math.floor(startIndex / pageSize) + 1;
          
                  // Get paginated slice
                  const paginatedProducts = sortedProducts.slice(startIndex, endIndex);
          
                  // Build response
                  const edges = paginatedProducts.map(product => ({
                      cursor: Buffer.from(product.prod_id.toString()).toString('base64'),
                      node: product
                  }));
          
                  return {
                      edges,
                      pageInfo: {
                          startCursor: edges[0]?.cursor || null,
                          endCursor: edges[edges.length - 1]?.cursor || null,
                          hasNextPage: endIndex < sortedProducts.length,
                          hasPreviousPage: startIndex > 0,
                          currentPage,
                          totalPages
                      },
                      totalCount
                  };
              } catch (error) {
                  throw new Error(`Pagination error: ${error.message}`);
              }
          } */
        products: async (_, { first, after, last, before, searchText, category, sortBy, sortOrder, pageSize = 5 }) => {
            try {
                // 1. Fetch all products
                let products = await Product.find();


                // 2. Apply filters
                if (searchText) {
                    products = products.filter(p =>
                        p.name.toLowerCase().includes(searchText.toLowerCase())
                    );
                }
                if (category) {
                    products = products.filter(p => p.category === category);
                }

                // 3. Apply sorting
                const fieldMap = { "Product Name": "name", "prod_id": "prod_id" };
                const sortField = fieldMap[sortBy] || sortBy;
                const sortedProducts = [...products]; // Create a copy for sorting

                if (sortField) {
                    sortedProducts.sort((a, b) => {
                        const aValue = a[sortField];
                        const bValue = b[sortField];

                        if (typeof aValue === "number" && typeof bValue === "number") {
                            return sortOrder === "ASC" ? aValue - bValue : bValue - aValue;
                        }
                        if (typeof aValue === "string" && typeof bValue === "string") {
                            return sortOrder === "ASC" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
                        }
                        return 0;
                    });
                }

                // 4. Validate pagination parameters
                if (first && last) throw new Error('Cannot use both first and last');
                if ((first && before) || (last && after)) {
                    throw new Error('Mixing forward and backward pagination is invalid');
                }

                const totalCount = sortedProducts.length;
                const totalPages = Math.ceil(totalCount / pageSize);

                // 5. Cursor handling (prod_id only)
                const decodeCursor = (cursor) => {
                    if (!cursor) return null;
                    try {
                        return Buffer.from(cursor, 'base64').toString('ascii');
                    } catch {
                        throw new Error("Invalid cursor format");
                    }
                };

                const encodeCursor = (prod_id) => {
                    return Buffer.from(prod_id.toString()).toString('base64');
                };

                let afterProduct = (await Product.find({ "prod_id": after })).toString();
                console.log("After PRoduct find", afterProduct);

                // 6. Determine pagination window
                let startIndex = 0;
                let endIndex = sortedProducts.length;

                // Handle 'after' cursor
                if (after) {
                    const afterId = decodeCursor(after);
                    console.log('Looking for product with ID:', afterId); // Debug log
                    const afterIndex = sortedProducts.findIndex(p => p.prod_id === afterId);
                    console.log('Found at index:', afterIndex); // Debug log
                    if (afterIndex === -1) throw new Error("Item referenced by 'after' cursor not found");
                    startIndex = afterIndex + 1;
                }

                // Handle 'before' cursor
                if (before) {
                    const beforeId = decodeCursor(before);
                    const beforeIndex = sortedProducts.findIndex(p => p.prod_id === beforeId);
                    if (beforeIndex === -1) throw new Error("Item referenced by 'before' cursor not found");
                    endIndex = beforeIndex;
                }

                // Apply pagination limits
                if (first) {
                    endIndex = Math.min(startIndex + first, sortedProducts.length);
                } else if (last) {
                    startIndex = Math.max(endIndex - last, 0);
                }

                // 7. Calculate current page (1-based)
                const currentPage = Math.floor(startIndex / pageSize) + 1;

                // 8. Get paginated results
                const paginatedProducts = sortedProducts.slice(startIndex, endIndex);

                // 9. Build response
                const edges = paginatedProducts.map(product => ({
                    cursor: encodeCursor(product.prod_id),
                    node: product
                }));

                return {
                    edges,
                    pageInfo: {
                        startCursor: edges[0]?.cursor || null,
                        endCursor: edges[edges.length - 1]?.cursor || null,
                        hasNextPage: endIndex < sortedProducts.length,
                        hasPreviousPage: startIndex > 0,
                        currentPage: Math.min(currentPage, totalPages), // Ensure we don't exceed total pages
                        totalPages
                    },
                    totalCount
                };
            } catch (error) {
                throw new Error(`Pagination error: ${error.message}`);
            }
        },
        productsByCategoryAndSearch: async (_, { searchText, category }) => {
            try {
                if (!category) {
                    throw new Error("Category is required to filter products.");
                }
                // Base query to filter by category
                let query = { category };

                // If searchText is provided, add regex filter for name
                if (searchText && searchText.trim() !== "") {
                    query.name = { $regex: searchText, $options: "i" }; // Case-insensitive search
                }

                // Fetch products based on the query
                const filteredProducts = await Product.find(query);
                return filteredProducts;
            } catch (error) {
                throw new Error(`Failed to search products: ${error.message}`);
            }
        },
        categories: async () => {
            try {
                const categories = await Product.distinct("category");
                return categories;
            } catch (error) {
                throw new Error(`Failed to fetch categories: ${error.message}`);
            }
        },
        // Resolver for fetching products based on the category
        productsInCategory: async (_, { category }) => {
            try {
                // Query the products collection to find products with the matching category
                const products = await Product.find({ category });
                return products;
            } catch (error) {
                throw new Error(`Failed to fetch products by category: ${error.message}`);
            }
        },
    },
    Mutation: {
        createProduct: async (_, { product }) => {
            try {
                function generateProdId() {
                    const num = Math.floor(1000 + Math.random() * 9000); // 1000–9999
                    const letter = String.fromCharCode(65 + Math.floor(Math.random() * 26)); // A-Z
                    return `${num}${letter}`;
                }
                const newProduct = new Product({
                    prod_id: generateProdId(),
                    ...product
                });

                const savedProduct = await newProduct.save();
                console.log('Product added successfully:', savedProduct);
                return savedProduct;
            } catch (error) {
                console.error('Error adding user:', error);
                throw new Error(`Failed to create user: ${error.message}`);
            }
        },
        deleteProduct: async (_, { prod_id }) => {
            try {
                const deletedProduct = await Product.findOneAndDelete({ prod_id });
                if (!deletedProduct) {
                    throw new Error("Product not found");
                }
                console.log("Product deleted Successfully", deletedProduct);
                return deletedProduct;
            } catch (error) {
                console.error("Error deleting product", error);
                throw new Error(`Failed to delete product: ${error.message}`);
            }
        }
    }
}
export default productResolvers;

