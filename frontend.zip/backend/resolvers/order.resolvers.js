import { orders } from "../_dummy_data/dummyData.js"

const orderResolvers = {
    Query: {
        orders(){
            return orders;
        }
    }
}

export default orderResolvers;