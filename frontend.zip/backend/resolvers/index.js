import { mergeResolvers } from "@graphql-tools/merge";
import userResolvers from "../resolvers/user.resolvers.js";
import cartResolvers from "../resolvers/cart.resolvers.js";
import productResolvers from "../resolvers/product.resolvers.js";
import orderResolvers from "../resolvers/order.resolvers.js";

const mergedResolvers = mergeResolvers([userResolvers, cartResolvers, productResolvers, orderResolvers ]);

export default mergedResolvers;