import mongoose from 'mongoose'; // Added missing mongoose import
import User from '../models/users.model.js';

const userResolvers = {
    Query: {
        users: async () => {
            try {
                const users = await User.find();
                return users;
            } catch (error) {
                throw new Error(`Failed to fetch users: ${error.message}`);
            }
        },
    },
    Mutation: {
        createUser: async (_, { user }) => { // Destructured args 
            try {
                // Create a new user instance
                const newUser = new User({
                    user_id: new mongoose.Types.ObjectId(), // Generate a new ObjectId
                    ...user // Spread the user input fields
                });

                // Save the user to the database
                const savedUser = await newUser.save();
                console.log('User added successfully:', savedUser);
                return savedUser;
            } catch (error) {
                console.error('Error adding user:', error);
                throw new Error(`Failed to create user: ${error.message}`);
            }
        },
        deleteUser: async (_, { user_id }) => {
            try {
                const deletedUser = await User.findOneAndDelete({ user_id });
                if (!deletedUser) {
                    throw new Error('User not found');
                }

                console.log('User deleted successfully:', deletedUser);
                return deletedUser;
            } catch (error) {
                console.error('Error deleting user:', error);
                throw new Error(`Failed to delete user: ${error.message}`);
            }
        }
    }
};

export default userResolvers;


/*
-------
Mutation for ADDING User:
-------
mutation AddUser($user: CreateUserInput!) {
  createUser(user: $user){
    name
    dob
    phone
  }
}

Variables for ADDING User:
{
  "user": {
    "name": "Kali ji Darling",
    "phone": "999 999 993",
    "dob": "44 44 4444",
    "address": "60 zinnia ln",
    "image": "example.com link"
  }
}
----------
Mutation for DELETETING User:
----------
mutation DeleteUser($user_id: ID!) {
   deleteUser(user_id: $user_id) {
       name
       image
       address
   }
}

VARIABLES for DELETE User:
{
  "user_id": "67e07aab45b2ec48bc980d56"
}
*/
