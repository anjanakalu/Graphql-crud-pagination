
### Rules for Structuring GraphQL Schemas

1. **Separation of Entities**:
   - For each distinct data entity (e.g., `products`, `carts`, `users`, `orders`), create a separate file named in the format `entityName.typeDefs.js` (e.g., `product.typeDefs.js`, `cart.typeDefs.js`).
   - Each file must encapsulate all schema definitions related to that entity, including `type`, `Query`, `Mutation`, and `input` types.

2. **Entity Type Definition (`type`)**:
   - Define a `type` for the entity (e.g., `type Product`) that includes all fields present in the data structure for that entity.
   - Use appropriate GraphQL scalar types (e.g., `ID`, `String`, `Float`, `Int`, `Boolean`) and mark fields as non-null (`!`) where required by the data model.

3. **Query Type Definition (`type Query`)**:
   - Include queries to retrieve data for the entity:
     - **Get all entities**: A query to return a list of all instances (e.g., `products: [Product!]!`), typically pluralized, returning a non-null array of non-null items.
     - **Get entity by ID**: A query to fetch a single instance by its unique identifier (e.g., `product(prod_id: ID!): Product`), returning a nullable result.

4. **Mutation Type Definition (`type Mutation`)**:
   - Include mutations for CRUD operations on the entity:
     - **Create**: A mutation to add a new entity (e.g., `createProduct(product: CreateProductInput!): Product`), returning the created entity (nullable if creation can fail).
     - **Update**: A mutation to modify an existing entity by its ID (e.g., `updateProduct(prod_id: ID!, product: UpdateProductInput!): Product`), returning the updated entity (nullable if not found or update fails).
     - **Delete**: A mutation to remove an entity by its ID (e.g., `deleteProduct(prod_id: ID!): Product`), returning the deleted entity (nullable if not found).
   - Use input types for `create` and `update` operations to define the data structure required for these actions.

5. **Input Type Definitions (`input`)**:
   - Define `input` types for `create` and `update` mutations:
     - **`Create<Entity>Input`**: Include all fields required to create a new entity, typically with non-null (`!`) constraints unless optional fields are allowed.
     - **`Update<Entity>Input`**: Include all fields that can be updated, typically optional (no `!`) to allow partial updates, unless certain fields are mandatory for updates.
   - Ensure field types match the corresponding `type` definition (e.g., `price: Float` in both `Product` and `CreateProductInput`).

6. **File Structure and Integration**:
   - Store all entity schema files in a `schema/` directory.
   - Use a main `index.js` file to combine all entity schemas using `mergeTypeDefs` from Apollo Server, adding relationship fields (e.g., `user: User` in `Cart`) as needed.

