import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
    order_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        unique: true,
        default: () => new mongoose.Types.ObjectId(),
    },
    cart_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Cart", // References Cart model
        unique: true, // Ensures one order per cart
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "User", // References User model
    },
    total_amount: {
        type: Number,
        required: true,
    },
    order_date: {
        type: Date,
        required: true,
        default: Date.now,
    },
    status: {
        type: String,
        required: true,
        enum: ["pending", "shipped", "delivered"],
        default: "pending",
    },
});

const Order = mongoose.model("Order", orderSchema);
export default Order;