import mongoose from "mongoose";

const cartItemSchema = new mongoose.Schema({
    prod_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Product", // Still references Product.prod_id
    },
    quantity: {
        type: Number,
        required: true,
        min: 1,
    },
    price_at_time: {
        type: Number,
        required: true,
    },
});

const cartSchema = new mongoose.Schema({
    cart_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        unique: true,
        default: () => new mongoose.Types.ObjectId(),
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "User",
        unique: true,
    },
    items: [cartItemSchema],
    total_amount: {
        type: Number,
        required: true,
        default: 0,
    },
    status: {
        type: String,
        required: true,
        enum: ["active", "converted"],
        default: "active",
    },
});

const Cart = mongoose.model("Cart", cartSchema);
export default Cart;