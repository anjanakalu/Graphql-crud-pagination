import mongoose from "mongoose";

// Define the userSchema schema with necessary fields and validation rules
const userSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        unique: true,
        default: () => new mongoose.Types.ObjectId(),
    },
    name: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    dob: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    image: {
        type: String,
        required: true
    }
});
// Create a User model based on the schema defined above
const User = mongoose.model("User", userSchema);

export default User;
