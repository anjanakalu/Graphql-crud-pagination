// ApolloClient.js
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client';

// Create the Apollo Client instance
const client = new ApolloClient({
  uri: 'http://localhost:4000', // Replace with your GraphQL server's endpoint
  cache: new InMemoryCache(),
});

export { client, ApolloProvider };
