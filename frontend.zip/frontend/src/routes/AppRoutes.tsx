import React, {ReactNode} from 'react';
import { BrowserRouter, Routes } from 'react-router-dom';

interface AppRoutesProps {
    children: ReactNode
}

const AppRoutes: React.FC<AppRoutesProps> = ({ children }) => {
    return (
        <BrowserRouter>
            <Routes>
                {children}
            </Routes>
        </BrowserRouter>
    )
}

export default AppRoutes;
