
import { Navigate, Route } from 'react-router-dom'
import './App.css'
import AppRoutes from "./routes/AppRoutes.js"
import Home from './pages/Home/Home.js'
import CategoriesList from './pages/categories/CategoriesList.js'
import ProductPage from './pages/products/ProductPage.js'
import ProductsList from './pages/products/ProductsList.js'
import Breadcrumbs from './sharedComponent/breadcrumbs/Breadcrumbs.js'
import Inventory from './pages/Inventory/Inventory.js'

function App() {


  return (
    <>
      {/* <Breadcrumbs/> */}
      <AppRoutes>
        {/* <Route path="/" element={<Home />} /> */}
        <Route path="/" element={<CategoriesList />} />
        <Route path="/products/:category" element={<ProductsList />} />
        <Route path="/all-products" element={<ProductPage />} />
        <Route path="/inv" element={<Inventory />} />
        <Route path="*" element={<Navigate to="/" />} />
      </AppRoutes>
    </>
  )
}

export default App;
