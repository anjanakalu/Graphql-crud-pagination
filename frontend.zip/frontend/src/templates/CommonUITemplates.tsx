import React, { ReactNode } from 'react'

const CommonUITemplates: React.FC<{ children: ReactNode }> = ({ children }) => {
    return (
        <div className='ml-10 mr-10'>
            {children}
        </div>
    )
}

export default CommonUITemplates;