import styles from './SearchComponent.module.css';

//Define prop types using an interface
interface SearchComponentProps {
    name?: string;
    id?: string;
    placeholder?: string;
    searchValue: string;
    setSearchValue: (value: string) => void;
}
const SearchComponent = ({
    name = "searchbar",
    id = "searchbar",
    placeholder = "Search...",
    searchValue,
    setSearchValue
}: SearchComponentProps) => {

    const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSearchValue(event.target.value);
    }
    return (
        <div className={styles.container}>
            <input
                type="text"
                name={name}
                id={id}
                value={searchValue}
                onChange={handleOnChange}
                placeholder={placeholder}
                className={styles.input}
            />
            <span className={styles.searchIcon}>
                🔍
            </span>
        </div>
    );
};

export default SearchComponent;