import FullPagination from "../breadcrumbs/pagination/FullPagination";

interface ProductTProps {
    prod_id: string;
    name: string;
    description: string;
    price: number;
    image: string;
    category: string;
}

interface NumberedProductProps extends ProductTProps {
    serialNo: number;
}

interface PageInfoT {
    startCursor: string;
    endCursor: string;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    currentPage: number;
    totalPages: number;
}

interface GlobalTableProps {
    productsList: NumberedProductProps[];
    pageInfo: PageInfoT;
    totalCount: number;
    setAfterCursor: (cursor: string | null) => void;
    setBeforeCursor: (cursor: string | null) => void;
    pageSize: number;
}


const GlobalTable = ({ productsList, pageInfo, totalCount, setAfterCursor, setBeforeCursor, pageSize }: GlobalTableProps) => {

    return (
        <div className="overflow-x-auto pt-2">
            <FullPagination
                pageInfo={pageInfo}
                totalCount={totalCount}
                setAfterCursor={setAfterCursor}
                setBeforeCursor={setBeforeCursor}
                pageSize={pageSize}
            />
            <table className="w-full min-w-max border-collapse border border-gray-300">
                <thead>
                    <tr className="bg-gray-100">
                        <th scope="col" className="border border-gray-300 px-4 py-2 text-left">
                            S.No
                        </th>
                        <th scope="col" className="border border-gray-300 px-4 py-2 text-left">
                            Name
                        </th>
                        <th scope="col" className="border border-gray-300 px-4 py-2 text-left">
                            Description
                        </th>
                        <th scope="col" className="border border-gray-300 px-4 py-2 text-left">
                            Price
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {productsList.map((item) => (
                        <tr
                            key={item.prod_id}
                            className="odd:bg-white even:bg-gray-50 hover:bg-gray-200 transition-colors"
                        >
                            <td className="border border-gray-300 px-4 py-2">{item.serialNo}</td>
                            <td className="border border-gray-300 px-4 py-2">{item.name}</td>
                            <td className="border border-gray-300 px-4 py-2">{item.description}</td>
                            <td className="border border-gray-300 px-4 py-2">{item.price}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div>Pagination:</div>
            {/* {productsList.length} */}
            {/* <CustomPagination /> */}

        </div>
    );
};

export default GlobalTable;



/* 
1. Pagination Parameters
currentPage: The current page number being viewed.
pageSize: The number of items per page.
totalItems: Total number of items across all pages (needed for calculating totalPages).
totalPages: Total number of pages (calculated as Math.ceil(totalItems / pageSize)).

2. Pagination Information to Track
items: The data items for the current page.
startIndex / endIndex: The range of indices for items on the current page (optional for display purposes).
hasPreviousPage: Boolean indicating if there’s a previous page (currentPage > 1).
hasNextPage: Boolean indicating if there’s a next page (currentPage < totalPages).
isLoading: Boolean flag for when data is being fetched.

*/