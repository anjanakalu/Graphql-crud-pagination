import React from 'react';

// Define the type for the props
type InfoCardProps = {
  variant: 'product' | 'user';  // Only 'product' or 'user'
  price?: number;               // Price is optional for user cards
  title: string;
  description: string;
  imageUrl: string;
  label?: string;               // Optional label (e.g., "New", "Best Seller")
  onClickAction?: () => void;   // Optional onClick action
};

const InfoCard = ({
  variant = 'product',
  price = 10,
  title = "Sanu Cookie",
  description = "Best Cookie",
  imageUrl = 'https://handletheheat.com/wp-content/uploads/2020/10/BAKERY-STYLE-CHOCOLATE-CHIP-COOKIES-9-637x637-1.jpg',
  label = 'New',               // Default label value if none is provided
  onClickAction = () => alert('Button clicked!'), // Default button click handler
  
}: InfoCardProps) => {
  // Conditional className based on variant
  const cardClass = variant === 'product'
    ? 'border-green-400 shadow-lg'
    : 'border-blue-400 bg-blue-50 text-center';


  return (
    <div
      className={`relative bg-white shadow-lg rounded-lg overflow-hidden border-2 ${cardClass} w-80`}
    >
      {/* Label */}
      <div>
        <span className="bg-red-400 text-white p-1 text-xs absolute top-2 right-2 rounded-md">
          {label}
        </span>
      </div>

      {/* Image */}
      <div className="w-full h-48 flex justify-center items-center bg-gray-200">
        <img className="object-cover w-full h-full" src={imageUrl} alt={title} />
      </div>

      {/* Content */}
      <div className="p-4">
        <div className='flex flex-col items-start'>
          {/* Conditionally render price for product cards */}
          {variant === 'product' && price && (
            <div className="text-lg font-semibold text-green-500">Price: ${price}</div>
          )}

          {/* Common title and description */}
          <div className="text-xl font-bold mt-2">{title}</div>
          <div className="text-sm text-gray-600 mt-1">{description}</div>
        </div>
        {/* Button */}
        <button
          className="mt-4 w-full py-2 px-4 rounded-lg bg-yellow-400 hover:bg-yellow-500 text-white font-semibold"
          onClick={onClickAction}
        >
          {variant === 'product' ? 'Buy Now' : 'Follow'}
        </button>
      </div>
    </div>
  );
};

export default InfoCard;
