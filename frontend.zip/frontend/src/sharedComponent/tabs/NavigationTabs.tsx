
interface NavigationTabsProps {
    isActive: boolean;
    label: string;
    onClick: () => void;
}

const NavigationTabs = ({ isActive, label, onClick }: NavigationTabsProps) => {
    return (
        // <div className={`tab ${isActive ? "active" : ""}`}
        <span className={`tab p-4 cursor-pointer   ${isActive ? "bg-blue-500" : "bg-gray-200 text-gray-600"}`}
            onClick={onClick}
        >
            {label}
        </span>
    )
}
export default NavigationTabs;