import React, { useState } from 'react'

interface PageInfoT {
  startCursor: string;
  endCursor: string;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
  currentPage: number;
  totalPages: number;
}

interface PaginationProps {
  pageInfo: PageInfoT;
  totalCount: number;
  setAfterCursor: (cursor: string | null) => void;
  setBeforeCursor: (cursor: string | null) => void;
  pageSize: number;
}



const FullPagination = ({ pageInfo, totalCount, setAfterCursor, setBeforeCursor, pageSize }: PaginationProps) => {
  // total
  // Page size
  // console.log("pageInfo", pageInfo, totalCount)
  // const totalCounts = 29;
  // const pageSize = 5;
  const [currentPage, setCurrentPage] = useState(1);
  const pageNumbers = Array.from({ length: Math.ceil(totalCount / pageSize) }, (_, i) => i + 1);





  const handlePaginationClick = (ele: number) => {
    setCurrentPage(ele);
  }

  const startCursor = pageInfo.startCursor;
  const endCursor = pageInfo.endCursor;

  const handleClickPrevious = () => {
    setBeforeCursor(endCursor);
  }

  const handleClickNext = () => {
    setAfterCursor(startCursor);
  }



  return (
    <div>
      FullPagination::
      <button
        className='m-6 p-2 bg-amber-400 font-bold'
        onClick={handleClickPrevious}
      >Previous</button>
      {pageNumbers.map((ele: number, i: number) => (
        <button
          key={i}
          onClick={() => handlePaginationClick(ele)}
          style={{ margin: 6, padding: 6 }}
        >
          {ele}
        </button>
      ))}
      <button
        className='m-6 p-2 bg-amber-400 font-bold'
        onClick={handleClickNext}
      >Next</button>
    </div>
  )
}

export default FullPagination;




