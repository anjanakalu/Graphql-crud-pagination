import React from 'react'
import { Link } from 'react-router-dom';
import styles from "./breadcrumbs.module.css"

//  {/* <Route path="/" element={<Home />} /> */}
//  <Route path="/" element={<CategoriesList />} />
//  <Route path="/products/:category" element={<ProductsList />} />
//  <Route path="/all-products" element={<ProductPage />} />
//  <Route path="*" element={<Navigate to="/" />} />

let breadcrumbs = [
    { label: 'Home', link: '/' },
    { label: 'Categories', link: '/category' },
    { label: 'Products', link: '/products/:category' },
];

const Breadcrumbs = () => {

    return (
        <div className={styles.breadcrumbs} >
            {
                breadcrumbs.map((crumb:{label:string, link:string}, index) => (
                    <span key={index} className={styles.breadcrumbItem}>
                        {crumb.link ? (
                            <Link to={crumb.link}>{crumb.label}</Link>
                        ) : (
                            <span>{crumb.label}</span>
                        )}
                        {index < breadcrumbs.length-1 ? <span>/</span>: null}
                    </span>
                ))
            }
        </div>
    )
}

export default Breadcrumbs;

