import { gql } from "@apollo/client";

// Reusable paginated query (but this won't work unless passed via variables)
export const GET_PAGINATED_INVENTORY_PRODUCTS = gql`
  query GetInventoryProductsPaginated(
    $first: Int
    $after: String
    $searchText: String
    $category: String
    $sortBy: String
    $sortOrder: String
    $pageSize: Int
  ) {
    products(
      first: $first
      after: $after
      searchText: $searchText
      category: $category
      sortBy: $sortBy
      sortOrder: $sortOrder
      pageSize: $pageSize
    ) {
      edges {
        cursor
        node {
          prod_id
          name
          description
          price
          category
          image
        }
      }
      pageInfo {
        startCursor
        endCursor
        hasNextPage
        hasPreviousPage
        currentPage
        totalPages
      }
      totalCount
    }
  }
`;