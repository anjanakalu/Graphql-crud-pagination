import { gql } from "@apollo/client";

// Define the reusable ProductFields fragment
export const PRODUCT_FIELDS = gql`
  fragment ProductFields on Product {
    prod_id
    name
    description
    price
    image
  }
`;

// Fetch all products, optionally using the fragment
export const GET_PRODUCTS = gql`
  query GetProducts {
    products {
      ...ProductFields
    }
  }
  ${PRODUCT_FIELDS}  # Include the fragment here
`;


// Search products using the fragment
export const GET_SEARCH_PRODUCTS = gql`
  query GetSearchProducts($searchText: String) {
    searchProducts(searchText: $searchText) {
      ...ProductFields
    }
  }
  ${PRODUCT_FIELDS}  # Include the fragment here
`;

// Fetch categories only ({ "data": { "categories": [ "books", "electronics", "fruits", "health", "toys" ] } })
export const GET_CATEGORIES = gql`
  query GetCategories {
    categories
  }
`;

// Fetch categories by products
export const GET_PRODUCTS_FOR_CATEGORY = gql`
  query ProductsByCategory($category: String!) {
    productsInCategory(category: $category) {
      ...ProductFields
    }
  }
  ${PRODUCT_FIELDS}  # Include the fragment here
`;

// 🔍 GraphQL query to fetch products by category with optional search text
export const GET_PRODUCTS_BY_CATEGORY_SEARCH = gql`
  query GetProductsByCategoryAndSearch($searchText: String, $category: String!) {
    productsByCategoryAndSearch(searchText: $searchText, category: $category) {
      ...ProductFields
    }
  }
  ${PRODUCT_FIELDS}  # Include the fragment here
`;
