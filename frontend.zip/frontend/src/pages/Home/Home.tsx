import React from 'react'


const Home = () => {
    return (
        <div>
            HOME
        </div>
    )
}

export default Home

/* import React from 'react'

interface HomeProps {
    title: string;
}

const Home = ({ title }: HomeProps) => {
    return (
        <div>
            {title}
            HOME
        </div>
    )
}

export default Home
 */