import { useQuery } from '@apollo/client';
import React, { useState } from 'react'
import { GET_PRODUCTS_BY_CATEGORY_SEARCH, GET_PRODUCTS_FOR_CATEGORY } from '../../graphql/queries';
import { useParams } from 'react-router-dom';
import InfoCard from '../../sharedComponent/card/InfoCard';
import styles from "./ProductsList.module.css";
import SearchComponent from '../../sharedComponent/searchbar/SearchComponent';
import Breadcrumbs from '../../sharedComponent/breadcrumbs/Breadcrumbs';

interface ProductByCategoryT {
  prod_id: string;
  name: string;
  description: string;
  price: number;
  image: string;
}

const ProductsList = () => {
  let params = useParams();
  const { category } = params;
  const [searchValue, setSearchValue] = useState<string>("");
  const queryVariables  = {
    category,
    ...(searchValue && { searchText: searchValue })
  }

  const { data, loading, error } = useQuery<{ productsByCategoryAndSearch: ProductByCategoryT[] }>(GET_PRODUCTS_BY_CATEGORY_SEARCH,
    {
      skip: !category, // Skips the query if category is undefined
      variables: category ? queryVariables  : undefined,
    }
  );


  if (loading) <div>Loading...</div>
  if (error) <div>Error...</div>

  const products: ProductByCategoryT[] = data ? data.productsByCategoryAndSearch || [] : [];

  return (
    <div>
      <Breadcrumbs />
      <SearchComponent
        searchValue={searchValue}
        setSearchValue={setSearchValue}
        placeholder='Search Product'
      />
      <div className={styles.cardContainer}>
        {products.map((product: ProductByCategoryT) => (
          <div key={product.prod_id} className={styles.cardWrapper}>
            <InfoCard
              title={product.name}
              variant="product"
              description={product.description}
              imageUrl={product.image}
              price={product.price}
              label="new"
            />
          </div>
        ))
        }
      </div>
    </div>
  )
}

export default ProductsList;