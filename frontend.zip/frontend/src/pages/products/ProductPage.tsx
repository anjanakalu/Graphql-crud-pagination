import { useQuery } from '@apollo/client';
import { GET_PRODUCTS, GET_SEARCH_PRODUCTS } from '../../graphql/queries';
import InfoCard from '../../sharedComponent/card/InfoCard';
import styles from './ProductPage.module.css'; // Import the CSS module
import SearchComponent from '../../sharedComponent/searchbar/SearchComponent';
import { useState } from 'react';

// Interface for product data structure
interface ProductArgs {
  prod_id: string;
  name: string;
  description: string;
  price: number;
  image: string;
}

// Interface for ProductPage component props (empty here as no props are passed)
interface ProductPageProps { }

// Interface for the GET_PRODUCTS query response
interface ProductQueryData {
  products: ProductArgs[];
}

// Interface for the GET_SEARCH_PRODUCTS query response
interface SearchProductQueryData {
  searchProducts: ProductArgs[];
}

const ProductPage = ({}: ProductPageProps) => {
  const [searchValue, setSearchValue] = useState<string>("");

  // Conditionally choose the query based on searchValue
  const query = searchValue ? GET_SEARCH_PRODUCTS : GET_PRODUCTS;
  const variables = searchValue ? { searchText: searchValue } : {};

  const { loading, error, data } = useQuery<
    ProductQueryData | SearchProductQueryData
  >(query, {
    variables, // Pass search value as a variable when searching
  });

  if (loading) return <h1>Loading...</h1>;
  if (error) return <div>Error: {error.message}</div>;

  // Extract products from the response, handling both query types
  const products: ProductArgs[] = searchValue
    ? (data as SearchProductQueryData)?.searchProducts || []
    : (data as ProductQueryData)?.products || [];

  return (
    <>
      <div>
        <SearchComponent
          searchValue={searchValue}
          setSearchValue={setSearchValue}
          placeholder="Search Product"
        />
      </div>
      <div className={styles.cardContainer}>
        {products.map((product: ProductArgs) => (
          <div key={product.prod_id} className={styles.cardWrapper}>
            <InfoCard
              title={product.name}
              variant="product"
              description={product.description}
              imageUrl={product.image}
              price={product.price}
              label="new"
            />
          </div>
        ))}
      </div>
    </>
  );
};

export default ProductPage;
/*
Rules to apply TypeScript to prevent errors in React:
1. Provide explicit types to all props received by components (e.g., InfoCard props should be typed in its definition).
2. Provide types to all data passed from parent to child components (e.g., ProductArgs for mapped products).
3. Define types for all function parameters to ensure type safety (e.g., map callback parameter typed as ProductArgs).
4. Explicitly type all variables where possible to avoid implicit `any` types (e.g., products typed as ProductArgs[]).
5. Ensure that GraphQL query responses are strongly typed using TypeScript types or interfaces (e.g., useQuery<ProductQueryData>).
6. Ensure all imported components (e.g., InfoCard) have their own prop types defined in their files.
7. Use consistent array iteration syntax (e.g., parentheses in map for cleaner JSX returns).
8. Provide correct types for event handlers (e.g., (event: React.MouseEvent) => void, not applicable here).
9. Prefer `type` or `interface` for defining data structures to maintain consistency (e.g., ProductArgs interface).
10. When using optional chaining (`?.`), ensure fallback values are correctly typed to prevent `undefined` errors (e.g., data?.products || []).

11. Optional: Use `useState` with an explicit type when the default state is ambiguous or for better clarity (e.g., useState<number>(0)).
12. Optional: Provide types to component return types for clarity (e.g., React.FC<ProductPageProps>). 
    - A React component typically returns JSX.Element, React.ReactNode, or null. TypeScript infers this implicitly.
13. Optional: Return type for functions when necessary for better clarity (e.g., (): Promise<void> => {}).
14. Optional: Use strict null checks with TypeScript's strict mode to handle undefined/null cases explicitly.
15. Optional: Add default props or default values where applicable to avoid runtime errors.
*/
