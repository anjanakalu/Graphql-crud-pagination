import React, { useState } from 'react';
import { useQuery } from '@apollo/client';

import CommonUITemplates from '../../templates/CommonUITemplates';
import NavigationTabs from '../../sharedComponent/tabs/NavigationTabs';
import GlobalTable from '../../sharedComponent/table/GlobalTable';

// import { GET_PRODUCTS_BY_CATEGORY_SEARCH, } from '../../graphql/queries';
import { GET_PAGINATED_INVENTORY_PRODUCTS } from '../../graphql/paginationQueries';

// Types for Tab items and Products
interface TabItem {
    label: string;
    category: string;
}

interface ProductT {
    prod_id: string;
    name: string;
    description: string;
    price: number;
    image: string;
    category: string;
}

interface NumberedProductT extends ProductT {
    serialNo: number;
}

interface PageInfoT {
    startCursor: string;
    endCursor: string;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    currentPage: number;
    totalPages: number;
}

const Inventory = () => {
    // Tab configuration
    const tabItems: TabItem[] = [
        { label: "Books", category: "books" },
        { label: "Electronics", category: "electronics" },
        { label: "Fruits", category: "fruits" },
        { label: "Health", category: "health" },
        { label: "Toys", category: "toys" },
        { label: "Auto", category: "auto" },
    ];

    // State to track currently selected tab
    const [activeTabIndex, setActiveTabIndex] = useState(0);

    // Derive selected category from active tab
    const selectedCategory = tabItems[activeTabIndex].category;

    // GraphQL query to fetch products based on category
    //   const { data, error, loading } = useQuery(GET_PRODUCTS_BY_CATEGORY_SEARCH, {
    //     variables: { category: selectedCategory }
    //   });

    const pageSize: number = 5;

    const { data, loading, error } = useQuery(GET_PAGINATED_INVENTORY_PRODUCTS, {
        variables: {
            first: pageSize,
            after: null,
            before: null,
            searchText: '',
            category: selectedCategory,
            sortBy: "name",
            sortOrder: "ASC",
            pageSize: pageSize
        }
    })

    const [afterCursor, setAfterCursor] = useState<string | null>(null);
    const [beforeCursor, setBeforeCursor] = useState<string | null>(null);

    console.log(afterCursor);
    console.log(beforeCursor);

    // Tab click handler
    const handleTabClick = (index: number) => {
        setActiveTabIndex(index);
    };

    // Handle loading and error states
    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error loading products.</div>;

    const edges = data?.products?.edges || [];

    const products: ProductT[] = edges.map((edge: any) => edge.node);

    // Extract pageInfo for pagination
    const pageInfo: PageInfoT = data?.products?.pageInfo;
    const totalCount: number = data?.products?.totalCount;

    // Extract product list and add serial numbers for display
    // const products: ProductT[] = data?.productsByCategoryAndSearch || [];
    const numberedProducts: NumberedProductT[] = products.map((product, index) => ({
        ...product,
        serialNo: index + 1
    }));

    return (
        <CommonUITemplates>
            {/* Navigation Tabs */}
            <div className="flex">
                {tabItems.map((tab, index) => (
                    <NavigationTabs
                        key={index}
                        label={tab.label}
                        isActive={index === activeTabIndex}
                        onClick={() => handleTabClick(index)}
                    />
                ))}
            </div>

            {/* Table displaying product data */}
            <GlobalTable
                productsList={numberedProducts}
                pageInfo={pageInfo}
                totalCount={totalCount}
                setAfterCursor={setAfterCursor}
                setBeforeCursor={setBeforeCursor}
                pageSize={pageSize}
            />
        </CommonUITemplates>
    );
};

export default Inventory;
