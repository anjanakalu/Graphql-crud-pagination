import { useQuery } from "@apollo/client";
import React from "react";
import { GET_CATEGORIES } from "../../graphql/queries";
import { useNavigate } from "react-router-dom";

const CategoriesList: React.FC = () => {
  // useQuery fetches categories data from GraphQL API
  // - `loading`: Indicates if the request is in progress
  // - `data`: Holds the fetched categories
  // - `error`: Captures any errors during the request
  const { loading, data, error } = useQuery<{categories: string[]}>(GET_CATEGORIES);


  const navigate = useNavigate();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error loading categories</div>;

  const categories: string[] = data?.categories || [];
console.log("categories", categories);
  // Function to navigate to the products page for the selected category
  const handleCategories = (category: string) => {
    navigate(`/products/${category}`);
  };

  return (
    <div>
      {categories.map((category, index) => (
        <div key={index}>
          {/* Clicking the button navigates to the corresponding product list */}
          <button onClick={() => handleCategories(category)}>
            {category}
          </button>
        </div>
      ))}
    </div>
  );
};

export default CategoriesList;
