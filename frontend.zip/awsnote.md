instance in aws and virtual/computer/ server
database aws and cluster means same

neptune database include 2 things cluster and one is external writer which function as a reader, 
they have built in reader and writer
